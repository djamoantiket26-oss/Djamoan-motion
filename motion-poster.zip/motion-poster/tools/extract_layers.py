"""
Splits the ORIGINAL poster into animatable layers using its own pixels.
Nothing is redrawn: every layer is cut from tools/original-poster.jpeg.

Outputs -> public/layers/*.png|jpg and src/layout.ts
Run:  python3 tools/extract_layers.py
"""
import json, os
import numpy as np, cv2
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT = os.path.join(ROOT, "public", "layers")
os.makedirs(OUT, exist_ok=True)

src = np.array(Image.open(os.path.join(HERE, "original-poster.jpeg")).convert("RGB"))
H, W = src.shape[:2]
assert (W, H) == (1080, 1920), "poster must be 1080x1920"

INK = (24, 24, 28)  # near-black of the original type

def save_rgba(name, rgb, alpha, box):
    x0, y0, x1, y1 = box
    a = np.clip(alpha[y0:y1, x0:x1], 0, 1)
    img = np.dstack([rgb[y0:y1, x0:x1], (a * 255).astype(np.uint8)])
    Image.fromarray(img, "RGBA").save(os.path.join(OUT, name))

# ---------------------------------------------------------------- background
strip = src[0:160]
tiles, flip = [], False
while sum(t.shape[0] for t in tiles) < H:
    tiles.append(strip[::-1] if flip else strip)
    flip = not flip
bg = np.vstack(tiles)[:H]
Image.fromarray(bg).save(os.path.join(OUT, "bg.jpg"), quality=95)

# ---------------------------------------------------------------- pink shapes
blur = cv2.GaussianBlur(src, (0, 0), 0.8).astype(int)
R, G, B = blur[..., 0], blur[..., 1], blur[..., 2]
pink = ((R - G > 110) & (B - G > 60) & (R > 150)).astype(np.uint8)
pink = cv2.morphologyEx(pink, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
n, lab, st, cen = cv2.connectedComponentsWithStats(pink, connectivity=8)
comps = [i for i in range(1, n) if st[i][4] > 200]
bursts_ids = sorted(comps, key=lambda i: -st[i][4])[:2]
dot_ids = [i for i in comps if i not in bursts_ids]

def fill_holes(m):
    inv = (1 - m).astype(np.uint8)
    nn, l2, s2, _ = cv2.connectedComponentsWithStats(inv, connectivity=4)
    out = m.copy()
    for k in range(1, nn):
        x, y, w, h, a = s2[k]
        touches = x == 0 or y == 0 or x + w >= m.shape[1] or y + h >= m.shape[0]
        if not touches:
            out[l2 == k] = 1
    return out

def pink_layer(mask_full, name, pad=3):
    ys, xs = np.where(mask_full)
    x0, x1, y0, y1 = xs.min() - pad, xs.max() + pad + 1, ys.min() - pad, ys.max() + pad + 1
    m = mask_full.astype(np.uint8)
    core = cv2.erode(m, np.ones((3, 3), np.uint8))
    rgb = src.copy()
    # colour for the 1px antialias rim: pull from the interior
    mean_pink = src[core > 0].reshape(-1, 3).mean(0)
    rim = (m > 0) & (core == 0)
    rgb[rim] = mean_pink.astype(np.uint8)
    rgb[m == 0] = mean_pink.astype(np.uint8)
    alpha = cv2.GaussianBlur(m.astype(np.float32), (0, 0), 0.7)
    save_rgba(name, rgb, alpha, (x0, y0, x1, y1))
    return dict(file=name, x=int(x0), y=int(y0), w=int(x1 - x0), h=int(y1 - y0))

layout = {"W": W, "H": H}

bursts = []
photo_hole = np.zeros((H, W), np.uint8)
for k, i in enumerate(sorted(bursts_ids, key=lambda i: cen[i][1])):
    m = fill_holes((lab == i).astype(np.uint8))
    m = cv2.erode(m, np.ones((3, 3), np.uint8))  # trim rim fringe
    m = cv2.dilate(m, np.ones((3, 3), np.uint8))
    d = pink_layer(m, f"burst_{k}.png")
    d["cx"] = float(cen[i][0]); d["cy"] = float(cen[i][1])
    bursts.append(d)
    photo_hole |= cv2.dilate(m, np.ones((17, 17), np.uint8))
layout["bursts"] = bursts

dots = []
cx0, cy0 = 531.0, 943.0
for i in dot_ids:
    m = (lab == i).astype(np.uint8)
    m = fill_holes(m)
    photo_hole |= cv2.dilate(m, np.ones((9, 9), np.uint8))
    ang = (np.degrees(np.arctan2(cen[i][1] - cy0, cen[i][0] - cx0)) + 90 + 360) % 360  # clockwise from top
    dots.append((ang, i, m))
dots.sort(key=lambda t: t[0])
dl = []
for k, (ang, i, m) in enumerate(dots):
    d = pink_layer(m, f"dot_{k:02d}.png", pad=2)
    d["cx"] = float(cen[i][0]); d["cy"] = float(cen[i][1])
    dl.append(d)
layout["dots"] = dl

# ---------------------------------------------------------------- photograph
PX0, PY0, PX1, PY1 = 95, 433, 968, 1453
photo = src.copy()
hole = (photo_hole > 0).astype(np.uint8) * 255
photo = cv2.inpaint(photo, hole, 6, cv2.INPAINT_TELEA)
Image.fromarray(photo[PY0:PY1, PX0:PX1]).save(os.path.join(OUT, "photo.jpg"), quality=95)
layout["photo"] = dict(file="photo.jpg", x=PX0, y=PY0, w=PX1 - PX0, h=PY1 - PY0)

# ---------------------------------------------------------------- type
Rch = cv2.GaussianBlur(src, (0, 0), 0.6)[..., 0].astype(float)
ink_alpha = np.clip((165 - Rch) / (165 - 60), 0, 1)
ink_rgb = np.zeros_like(src); ink_rgb[:] = INK

def ink_components(y0, y1, kw, kh, minarea=40):
    m = (ink_alpha[y0:y1] > 0.3).astype(np.uint8)
    d = cv2.dilate(m, np.ones((kh, kw), np.uint8))
    nn, lb, _, _ = cv2.connectedComponentsWithStats(d, connectivity=8)
    res = []
    for i in range(1, nn):
        mm = (lb == i) & (m > 0)
        if mm.sum() < minarea: continue
        ys, xs = np.where(mm)
        res.append(dict(mask=mm, box=(xs.min() - 3, ys.min() + y0 - 3, xs.max() + 4, ys.max() + y0 + 4)))
    return res

def emit_ink(items, prefix):
    out = []
    for k, it in enumerate(items):
        full = np.zeros((H, W), np.float32)
        y0 = it["box"][1] + 3 - 3
        # place mask (cropped band) back into full-frame alpha
        full_mask = np.zeros((H, W), bool)
        full_mask[it["_y0"]:it["_y1"]] = it["mask"]
        full = ink_alpha * cv2.dilate(full_mask.astype(np.uint8), np.ones((5, 5), np.uint8))
        x0, y0, x1, y1 = it["box"]
        name = f"{prefix}_{k:02d}.png"
        save_rgba(name, ink_rgb, full, (x0, y0, x1, y1))
        out.append(dict(file=name, x=int(x0), y=int(y0), w=int(x1 - x0), h=int(y1 - y0)))
    return out

# title words (CAN'T / STOP)
t = ink_components(100, 420, 45, 3)
for it in t: it["_y0"], it["_y1"] = 100, 420
t.sort(key=lambda it: it["box"][0])
layout["title"] = emit_ink(t, "title")

# bottom line, one component per letter
l = ink_components(1470, 1900, 1, 17)
for it in l: it["_y0"], it["_y1"] = 1470, 1900
assert len(l) == 21, f"expected 21 letters, got {len(l)}"
lines = {"singing at": 9, "karaoke night": 12}
# reading order: by line, then x.  Line = which side of the two baselines
def line_of(it):
    x0, y0, x1, y1 = it["box"]; cx = (x0 + x1) / 2; cy = (y0 + y1) / 2
    # line 1 ("singing at") centre-line rises ~1620 -> 1530; line 2 ("karaoke night") ~1735 -> 1700
    l1 = 1625 - (cx - 220) * 0.16
    l2 = 1745 - (cx - 100) * 0.04
    return 0 if abs(cy - l1) < abs(cy - l2) else 1
for it in l: it["line"] = line_of(it)
l.sort(key=lambda it: (it["line"], it["box"][0]))
print("line1 letters:", sum(1 for it in l if it["line"] == 0), "line2 letters:", sum(1 for it in l if it["line"] == 1))
letters = emit_ink(l, "letter")
for it, d in zip(l, letters): d["line"] = it["line"]
layout["letters"] = letters

# ---------------------------------------------------------------- write layout
ts = "// AUTO-GENERATED by tools/extract_layers.py - do not edit by hand\n"
ts += "export const LAYOUT = " + json.dumps(layout, indent=2) + " as const;\n"
with open(os.path.join(ROOT, "src", "layout.ts"), "w") as f:
    f.write(ts)
print("ok:", len(dl), "dots,", len(bursts), "bursts,", len(letters), "letters,", len(layout["title"]), "title words")
