import json, re, os, numpy as np
from PIL import Image
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
L=json.loads(re.search(r"LAYOUT = (.*) as const", open(f"{ROOT}/src/layout.ts").read(), re.S).group(1))
D=f"{ROOT}/public/layers/"
c=Image.open(D+"bg.jpg").convert("RGBA")
p=L["photo"]; c.paste(Image.open(D+p["file"]).convert("RGBA"),(p["x"],p["y"]))
def over(items):
    for it in items:
        im=Image.open(D+it["file"]).convert("RGBA"); c.alpha_composite(im,(it["x"],it["y"]))
over(L["dots"]); over(L["bursts"]); over(L["title"]); over(L["letters"])
c=c.convert("RGB"); c.save("/home/claude/work/recomposite.png")
o=Image.open(f"{ROOT}/tools/original-poster.jpeg").convert("RGB")
d=np.abs(np.array(c).astype(int)-np.array(o).astype(int)).mean(2)
print("mean abs diff",d.mean().round(2),"| >60 px:",(d>60).mean().round(4))
Image.fromarray(np.hstack([np.array(o),np.array(c)])).resize((1080,960)).save("/home/claude/work/side_by_side.png")
