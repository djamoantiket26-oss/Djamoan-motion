# CAN'T STOP – motion poster (Remotion)

1080 × 1920 · 30 fps · 330 frames (11 s) · seamless loop · 120 BPM

Your original poster is **not redrawn**. `tools/extract_layers.py` cuts the
original JPEG into layers (title words, 21 individual letters, 31 pink dots,
2 bursts, the photograph, a clean yellow background) and Remotion only moves
them. `tools/layer-check_original-vs-layers.png` shows the original next to the
layers re-assembled.

## Run it

```bash
npm install
npm start          # opens Remotion Studio – scrub / preview live
npm run render     # -> out/cant-stop-motion-poster.mp4  (H.264, CRF 16)
npm run still      # -> out/frame.png (frame 150, for a quick check)
```

Needs Node 18+. If npm reports a Remotion version mismatch, run `npx remotion upgrade`.
Rendering is CPU-heavy because of the animated grain; `npx remotion render MotionPoster out/video.mp4 --concurrency=4` can help on small machines.

## Timeline (frames @ 30 fps, 1 beat = 15 frames)

| Frames   | What happens |
|----------|--------------|
| 0–5      | Empty yellow, grain + flicker, light "hit" |
| 6–30     | **CAN'T** then **STOP** scale up with bounce and rotation; camera impacts |
| 16–32    | Photo wipes open from the centre with a brightness flash |
| 30–62    | 31 pink dots pop in one by one round the frame |
| 52–70    | Two comic bursts pop in with rotation |
| 72–110   | "singing at karaoke night" letters fly in one by one from below, above and the sides, with random spin |
| 110–296  | Loop body: photo push-in/out, a pulse that travels round the dots every 2 beats, bursts and title hit on the beat, letters hop in a wave, camera shake on every beat |
| 296–326  | Everything scales/spins out → frame 329 is empty, matching frame 0 |

All periodic motion divides evenly into 330 frames, so the loop point has no jump.

## Tweaking

* `src/timing.ts` – BPM, camera impact frames, optional `AUDIO_SRC` (drop a 120 BPM track in `public/`).
* `src/Poster.tsx` – every delay, spring and amplitude is a plain number next to the element it controls.
* Changed the poster? Replace `tools/original-poster.jpeg` (1080×1920) and run `npm run layers`.
  It expects the same structure (two words of title, 21 bottom letters, two bursts).
