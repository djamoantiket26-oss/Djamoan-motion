import React from 'react';
import {
  AbsoluteFill,
  Audio,
  Easing,
  Img,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {LAYOUT} from './layout';
import {
  AUDIO_SRC,
  BEAT,
  DURATION,
  IMPACTS,
  TAU,
  beatHop,
  beatPulse,
  clamp,
  hash,
} from './timing';

type Box = {file: string; x: number; y: number; w: number; h: number};

/** One pixel-exact layer cut from the original poster. */
const Sprite: React.FC<{item: Box; style?: React.CSSProperties}> = ({item, style}) => (
  <Img
    src={staticFile(`layers/${item.file}`)}
    style={{
      position: 'absolute',
      left: item.x,
      top: item.y,
      width: item.w,
      height: item.h,
      ...style,
    }}
  />
);

export const Poster: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  // ------------------------------------------------------------ helpers
  const pop = (
    delay: number,
    cfg: {damping?: number; stiffness?: number; mass?: number} = {},
  ) =>
    spring({
      frame: frame - delay,
      fps,
      config: {damping: 9, stiffness: 180, mass: 0.7, ...cfg},
    });

  /** 1 -> 0 exit ramp. Every element is fully gone by frame ~326 so the loop is seamless. */
  const out = (start: number, dur: number) =>
    1 - Easing.in(Easing.cubic)(clamp((frame - start) / dur));

  const pulse = beatPulse(frame);
  const theta = (TAU * frame) / DURATION; // one full cycle per loop

  // ------------------------------------------------------------ camera
  const beatIdx = Math.floor(frame / BEAT);
  const kick = pulse * pulse;
  let camX =
    3.2 * kick * (hash(beatIdx * 1.7) * 2 - 1) + 0.8 * Math.sin((TAU * 41 * frame) / DURATION);
  let camY =
    3.2 * kick * (hash(beatIdx * 2.9 + 4) * 2 - 1) + 0.8 * Math.sin((TAU * 53 * frame) / DURATION + 1);
  let camRot =
    0.3 * kick * (hash(beatIdx * 0.7 + 9) * 2 - 1) + 0.15 * Math.sin((TAU * 7 * frame) / DURATION);
  for (const ev of IMPACTS) {
    if (frame >= ev.f) {
      const a = ev.a * Math.exp(-(frame - ev.f) / 3.5);
      const ang = hash(ev.f) * TAU;
      camX += a * Math.cos(ang);
      camY += a * Math.sin(ang);
      camRot += a * 0.02 * Math.cos(ang * 2);
    }
  }
  const camScale = 1 + 0.006 * pulse;

  // ------------------------------------------------------------ background: flicker
  const flicker =
    1 +
    (hash(Math.floor(frame / 2) * 1.3) - 0.5) * 0.06 +
    (hash(Math.floor(frame / 5) + 99) > 0.93 ? 0.07 : 0) +
    0.025 * pulse +
    0.18 * Math.exp(-frame / 3); // light "hit" as the loop restarts
  const sat = 1 + (hash(Math.floor(frame / 3) + 7) - 0.5) * 0.08;

  // ------------------------------------------------------------ title (CAN'T / STOP)
  const title = LAYOUT.title.map((w, i) => {
    const e = pop(6 + i * 6, {damping: 7, stiffness: 230, mass: 0.75});
    const o = out(306 + i * 3, 18);
    const s = Math.max(0, e * o);
    const rot =
      (1 - e) * (i === 0 ? -9 : 9) +
      0.8 * Math.sin(TAU * (frame / 30) + i * 2) +
      (1 - o) * (i === 0 ? -14 : 14);
    const pump = 1 + 0.035 * beatPulse(frame, i * 7.5);
    return (
      <Sprite
        key={w.file}
        item={w}
        style={{
          opacity: s > 0.005 ? 1 : 0,
          transform: `translateY(${(1 - e) * -140}px) rotate(${rot}deg) scale(${s * pump})`,
        }}
      />
    );
  });

  // ------------------------------------------------------------ photograph (cinematic zoom)
  const P = LAYOUT.photo;
  const pcx = P.x + P.w / 2;
  const pcy = P.y + P.h / 2;
  const reveal = Easing.out(Easing.cubic)(clamp((frame - 16) / 16)) * out(312, 14);
  const flash = frame >= 16 ? 1 + 0.9 * Math.exp(-(frame - 16) / 3) : 1;
  // slow push-in and back out (loops), with a tiny kick on each beat
  const zoom = 1.035 - 0.035 * Math.cos(theta) + 0.008 * pulse;
  const panX = (zoom - 1) * P.w * 0.4 * Math.sin(theta);
  const panY = (zoom - 1) * P.h * 0.4 * Math.sin(2 * theta + 1);
  const zoomTransform = `translate(${panX}px, ${panY}px) scale(${zoom})`;

  // ------------------------------------------------------------ comic bursts
  const bursts = LAYOUT.bursts.map((b, i) => {
    const e = pop(52 + i * 10, {damping: 6, stiffness: 240, mass: 0.6});
    const o = out(300 + i * 4, 12);
    const s = Math.max(0, e * o);
    const rot =
      (1 - e) * (i === 0 ? -30 : 26) +
      1.4 * Math.sin(TAU * (frame / 30) + i * 1.7) +
      (1 - o) * (i === 0 ? 40 : -40);
    const pump = 1 + 0.05 * beatPulse(frame, i * 7.5);
    return (
      <Sprite
        key={b.file}
        item={b}
        style={{
          opacity: s > 0.005 ? 1 : 0,
          transform: `rotate(${rot}deg) scale(${s * pump})`,
        }}
      />
    );
  });

  // ------------------------------------------------------------ pink border dots (sequential pulse)
  const N = LAYOUT.dots.length;
  const dots = LAYOUT.dots.map((d, k) => {
    const e = pop(30 + k * 1.0, {damping: 8, stiffness: 260, mass: 0.5});
    const o = out(302 + k * 0.35, 10);
    const s = Math.max(0, e * o);
    // a wave travels clockwise round the frame once every 2 beats (30 frames)
    const w = (frame % 30) / 30;
    let dd = Math.abs(w - k / N);
    dd = Math.min(dd, 1 - dd);
    const bump = Math.exp(-Math.pow((dd * N) / 1.5, 2));
    const base = 1 + 0.04 * pulse;
    return (
      <Sprite
        key={d.file}
        item={d}
        style={{
          opacity: s > 0.005 ? 1 : 0,
          transform: `scale(${s * (base + 0.5 * bump)})`,
          filter: `brightness(${1 + 0.3 * bump})`,
        }}
      />
    );
  });

  // ------------------------------------------------------------ kinetic typography (singing at karaoke night)
  const letters = LAYOUT.letters.map((l, i) => {
    const e = pop(72 + i * 1.7, {damping: 8, stiffness: 200, mass: 0.65});
    const o = out(296 + i * 0.7, 14);
    const s = Math.max(0, e * o);
    const dir = i % 3;
    const from: [number, number] =
      dir === 0 ? [0, 260] : dir === 1 ? [0, -260] : [(i % 2 ? 1 : -1) * 220, 80];
    const rot0 = (hash(i + 1) - 0.5) * 90;
    const hop = -7 * beatHop(frame, i * 1.5); // wave of hops running through the line
    const x = (1 - e) * from[0];
    const y = (1 - e) * from[1] + hop + (1 - o) * 180;
    const rot = (1 - e) * rot0 + 2 * Math.sin(TAU * (frame / 30) + i * 0.6) + (1 - o) * rot0 * 0.5;
    return (
      <Sprite
        key={l.file}
        item={l}
        style={{
          opacity: s > 0.005 ? 1 : 0,
          transform: `translate(${x}px, ${y}px) rotate(${rot}deg) scale(${s})`,
        }}
      />
    );
  });

  // ------------------------------------------------------------ grain (screen space, re-seeded every 2 frames)
  const grainSeed = Math.floor(frame / 2) % 97;

  return (
    <AbsoluteFill style={{backgroundColor: '#E8DF14', overflow: 'hidden'}}>
      {AUDIO_SRC ? <Audio src={staticFile(AUDIO_SRC)} /> : null}

      {/* ---- everything inside the camera shakes together ---- */}
      <AbsoluteFill
        style={{transform: `translate(${camX}px, ${camY}px) rotate(${camRot}deg) scale(${camScale})`}}
      >
        {/* background: tiled with overscan so the shake never shows an edge */}
        <AbsoluteFill style={{filter: `brightness(${flicker}) saturate(${sat})`}}>
          {[-1, 0, 1].flatMap((ty) =>
            [-1, 0, 1].map((tx) => (
              <Img
                key={`${tx}${ty}`}
                src={staticFile('layers/bg.jpg')}
                style={{
                  position: 'absolute',
                  left: tx * LAYOUT.W,
                  top: ty * LAYOUT.H,
                  width: LAYOUT.W,
                  height: LAYOUT.H,
                }}
              />
            )),
          )}
        </AbsoluteFill>

        {/* photograph, clipped to its original frame */}
        <div
          style={{
            position: 'absolute',
            left: P.x,
            top: P.y,
            width: P.w,
            height: P.h,
            overflow: 'hidden',
            clipPath: `inset(${(1 - reveal) * 50}% 0% ${(1 - reveal) * 50}% 0%)`,
            transform: `scale(${0.9 + 0.1 * reveal})`,
          }}
        >
          <Img
            src={staticFile(`layers/${P.file}`)}
            style={{
              width: '100%',
              height: '100%',
              transform: zoomTransform,
              filter: `brightness(${flash}) contrast(1.02)`,
            }}
          />
        </div>

        {/* bursts ride the same zoom as the photo so they stay locked to it */}
        <AbsoluteFill style={{transformOrigin: `${pcx}px ${pcy}px`, transform: zoomTransform}}>
          {bursts}
        </AbsoluteFill>

        {dots}
        {title}
        {letters}
      </AbsoluteFill>

      {/* animated film grain */}
      <svg
        width={LAYOUT.W / 2}
        height={LAYOUT.H / 2}
        style={{
          position: 'absolute',
          left: 0,
          top: 0,
          transform: 'scale(2)',
          transformOrigin: '0 0',
          mixBlendMode: 'overlay',
          opacity: 0.38,
          pointerEvents: 'none',
        }}
      >
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence
            type="fractalNoise"
            baseFrequency="0.8"
            numOctaves={2}
            seed={grainSeed}
            stitchTiles="stitch"
          />
          <feColorMatrix
            type="matrix"
            values="0.33 0.33 0.33 0 0  0.33 0.33 0.33 0 0  0.33 0.33 0.33 0 0  0 0 0 0 1"
          />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" />
      </svg>
    </AbsoluteFill>
  );
};
