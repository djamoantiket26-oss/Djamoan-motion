// ---------------------------------------------------------------------------
// Global timing. 120 BPM -> one beat every 15 frames @ 30 fps.
// 330 frames = exactly 22 beats, so every periodic motion lands back on its
// starting value at the loop point.
// ---------------------------------------------------------------------------
export const FPS = 30;
export const DURATION = 330; // 11 s
export const BPM = 120;
export const BEAT = (FPS * 60) / BPM; // 15 frames

// Optional soundtrack: drop a file in /public (e.g. public/beat.mp3) and set
// AUDIO_SRC = 'beat.mp3'. Use a 120 BPM track so the hits line up with the visuals.
export const AUDIO_SRC: string | null = null;

export const TAU = Math.PI * 2;

export const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));

/** Deterministic pseudo-random 0..1 (so renders are identical every time). */
export const hash = (n: number) => {
  const s = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return s - Math.floor(s);
};

/** 0..1 position inside the current beat. */
export const beatPhase = (frame: number, offset = 0) =>
  (((frame - offset) % BEAT) + BEAT) % BEAT / BEAT;

/** Sharp hit on the beat that decays quickly (1 -> 0). */
export const beatPulse = (frame: number, offset = 0) =>
  Math.pow(1 - beatPhase(frame, offset), 3);

/** Smooth hop that peaks mid-beat (0 -> 1 -> 0). */
export const beatHop = (frame: number, offset = 0) =>
  Math.abs(Math.sin(Math.PI * beatPhase(frame, offset)));

// Camera impacts: frame, strength (px). They sync with the intro hits.
export const IMPACTS: {f: number; a: number}[] = [
  {f: 8, a: 16},
  {f: 14, a: 12},
  {f: 24, a: 10},
  {f: 54, a: 12},
  {f: 64, a: 12},
  {f: 74, a: 8},
  {f: 98, a: 10},
];
