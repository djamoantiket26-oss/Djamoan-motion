import React from 'react';
import {Composition} from 'remotion';
import {Poster} from './Poster';
import {DURATION, FPS} from './timing';
import {LAYOUT} from './layout';

export const Root: React.FC = () => {
  return (
    <Composition
      id="MotionPoster"
      component={Poster}
      durationInFrames={DURATION} // 330 frames = 11.0 s @ 30 fps
      fps={FPS}
      width={LAYOUT.W} // 1080
      height={LAYOUT.H} // 1920
    />
  );
};
